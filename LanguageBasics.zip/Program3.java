public class Program3{
	public static void main(String[] args){
		int a=Integer.parseInt(args[0])+Integer.parseInt(args[1]);
		System.out.println("sum is "+a);
	}
}