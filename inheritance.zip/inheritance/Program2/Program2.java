

public class Program2{

	public static void main(String[] args) {
		Employee e = new Employee("John", 5000000, 2019, "2132JSFJ");
		System.out.print(e);

	}

}
