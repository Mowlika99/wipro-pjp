

public class Square extends Shape{

	@Override
	public void Draw()
	{
		System.out.println("Drawing Square");
	}
	@Override
	public void Erase()
	{
		System.out.println("Erasing Square");
	}
}
