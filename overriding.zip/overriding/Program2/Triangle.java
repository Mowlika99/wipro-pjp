

public class Triangle extends Shape{

	@Override
	public void Draw()
	{
		System.out.println("Drawing Triangle");
	}
	@Override
	public void Erase()
	{
		System.out.println("Erasing Triangle");
	}
}
