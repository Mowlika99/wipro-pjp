

public class Shape {

	public void Draw()
	{
		System.out.println("Drawing Shape");
	}
	public void Erase()
	{
		System.out.println("Erasing Shape");
	}
}
