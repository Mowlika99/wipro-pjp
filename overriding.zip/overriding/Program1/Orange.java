

public class Orange extends Fruit{
	
	@Override
	public void eat()
	{
		System.out.println("its tastes like orange");
	}
}
