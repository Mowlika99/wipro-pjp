INSERT INTO my_employee
  VALUES (202,'Pat','Jay',20,NULL);

  SELECT
  * FROM
   employees
;       