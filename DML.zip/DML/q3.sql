INSERT INTO my_employee VALUES (201,'Michael','Harstein',20,13000);
    
SELECT
        employee_id,
        first_name,
        last_name,
        department_id,
        salary
    FROM
        employees
    WHERE
        employee_id = 201;

