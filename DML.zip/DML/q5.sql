INSERT INTO my_employee (
    employee_id,
    first_name,
    last_name,
    department_id
) VALUES (
    203,
    'Susan',
    'Marvis',
    40
);

select * from my_employee;