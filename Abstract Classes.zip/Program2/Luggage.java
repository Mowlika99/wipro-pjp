package Program2;

public class Luggage extends Compartment{

	@Override
	public String notice() {
		System.out.print("This is Luggage Class");
		return null;
	}

}
