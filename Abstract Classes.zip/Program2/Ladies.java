package Program2;

public class Ladies extends Compartment{

	@Override
	public String notice() {
		System.out.print("This is Ladies Class");
		return null;
	}

}
