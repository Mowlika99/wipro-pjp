package Program2;

public class General extends Compartment{

	@Override
	public String notice() {
		System.out.print("This is General Class");
		return null;
	}

}
