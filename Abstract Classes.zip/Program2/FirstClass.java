package Program2;

public class FirstClass extends Compartment{

	@Override
	public String notice() {
		System.out.print("This is First Class");
		return null;
	}

}
