package Program1;

public abstract class GeneralBank {
	
	public abstract double getSavingsInterestRate();
	
	public abstract double getFixedDepositInterestRate();
	
}
