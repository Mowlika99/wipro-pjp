
public class Program6 {
	public static void main(String[] args)
	{
		String a="hi";
		String b="hello";
		
		if(a.length() < b.length())
		{
			System.out.print(a+b+a);
		}
		else
		{
			System.out.print(b+a+b);
		}
	}
}
