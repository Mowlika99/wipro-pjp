
public class Program5 {
	public static void main(String[] args)
	{
		String input= "Sarthak";
		StringBuffer sb=new StringBuffer();
		
		sb.append(input);
		
		System.out.print(sb.substring(1,input.length()-1));
	}
}
