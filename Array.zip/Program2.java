import java.util.Scanner;
public class Program2{
	public static void main(String[] args)
	{
		int n;

		
Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = s.nextInt();
        int a[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n ; i++)
        {
            a[i] = s.nextInt();
         }
int max=a[0];
		int min=a[0];
		for(int i=0;i<a.length; i++)
		{
			if(a[i]>max)
			{
				max=a[i];
			}
			else if(a[i]<min)
			{
				min=a[i];
			}
		}
		System.out.println("Maximum element : "+max);
		System.out.print("Minimum element : "+min);
	}
}