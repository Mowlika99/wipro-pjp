import java.util.Scanner;
public class Program7
{

	public static void main (String[] args)  
    { 
        int n;

		
Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = s.nextInt();
        int arr[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n ; i++)
        {
            arr[i] = s.nextInt();
         }
        int n1 = arr.length; 

        int i,j;

        for (i=0; i < n1; i++) 
        { 
            
            for (j=0; j < i; j++) 
            {
            	if (arr[i] == arr[j]) 
                break;
            }
            
              
                     
            if (i == j) 
            System.out.print( arr[i] + " "); 
        } 
  
    }
}
