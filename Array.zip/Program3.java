import java.util.Scanner;
public class Program3{
	public static void main(String[] args)
	{
		int n;
		int flag=0;
		
		Scanner input=new Scanner(System.in);
System.out.print("Enter total number of elements:");
 n = input.nextInt();
int data[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n ; i++)
        {
            data[i] = input.nextInt();
         }
System.out.print("Enter Element to Search :");
		int searchElement=input.nextInt();

		for(int i=0 ; i<data.length;i++)
		{

			if(data[i] == searchElement)
			{
				System.out.print("Element is present at index : "+i);
				flag=1;
			}
			
		}
		if(flag==0)
		{
			System.out.print("-1");
		}

		

	}

}