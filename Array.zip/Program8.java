import java.util.Scanner;
public class Program8
{
	public static void main (String[] args)  
    { 
      int n;

		
Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = s.nextInt();
        int data[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n ; i++)
        {
            data[i] = s.nextInt();
         }
        int size = data.length;
        int flag=0;

        int idx1=0,idx2=0;
        int total=0;

        for(int i=0 ; i < size ; i++)
        {
            if(data[i]==6)
            {
                for(int j=i ; j < size ; j++)
                {
                    if(data[j]==7 && flag==0)
                    {
                        flag=flag+1;
                        idx1=idx1+i;
                        idx2=idx2+j;

                        for(int k=0 ; k < idx1 ; k++)
                        {
                            total=total+data[k];
                        }
                        for(int k=idx2+1 ; k < size ; k++)
                        {
                            total=total+data[k];
                        }
                        System.out.print(total);
                    }
                }
            }
        }
        if(flag==0)
        {
            for(int l=0;l<size;l++)
            {
                total=total+data[l];
            }
            System.out.print(total);
        }    
    }
}
