import java.util.Arrays;
import java.util.Scanner;
public class Program5{
	public static void main(String[] args)
	{
int n;

		
Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = s.nextInt();
        int data[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n ; i++)
        {
            data[i] = s.nextInt();
         }
		
		int lenOfArray=data.length;
		Arrays.sort(data);
		System.out.println("Largest two number in array : "+data[lenOfArray-1]+" and "+data[lenOfArray-2]);
		System.out.print("Smallest two number in array : "+data[0]+" and "+data[1]);
	}

}