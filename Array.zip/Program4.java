import java.util.Scanner;
public class Program4{
	public static void main(String[] args)
	{
		int n;

		
Scanner s = new Scanner(System.in);
        System.out.print("Enter no. of elements you want in array:");
        n = s.nextInt();
        int data[] = new int[n];
        System.out.println("Enter all the elements:");
        for(int i = 0; i < n ; i++)
        {
            data[i] = s.nextInt();
         }

		for(int i=0; i<data.length;i++)
		{
			System.out.print((char)data[i]+" ");	
		}
		

	}

}