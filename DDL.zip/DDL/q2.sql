
INSERT INTO dept VALUES (
    10,
    'Accounts'
);


INSERT INTO dept VALUES (
    null,
    'TT'
);


update dept set dept_id = 20
where dept_name = 'TT';

INSERT INTO dept VALUES (
    A1,
    'Accounts'
);

update dept set dept_id = 30
where dept_name = 'Accounts';


INSERT INTO dept
    SELECT
        department_id,
        department_name
    FROM
        departments;

