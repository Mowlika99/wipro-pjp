class Box
{
	double depth;
	double width;
	double height;
	Box(double d,double w ,double h)
	{
		depth=d;
		width=w;
		height=h;
	}

	double volume()
	{
		return depth*width*height;
	}
}

public class Program1{
	public static void main(String[] args)
	{
		Box b=new Box(10,20,30);
		System.out.println(b.volume());
	}
}